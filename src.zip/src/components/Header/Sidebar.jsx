import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiHome, FiBookOpen, FiUser, FiSettings, FiX, FiLogOut } from 'react-icons/fi';
import styles from './Sidebar.module.css';

const navItems = [
  { to: '/dashboard', icon: <FiHome />,     label: 'Dashboard' },
  { to: '/lessons',   icon: <FiBookOpen />,  label: 'Lessen' },
  { to: '/students',  icon: <FiUser />,      label: 'Studenten' },
  { to: '/settings',  icon: <FiSettings />,  label: 'Instellingen' },
];

const Sidebar = ({ isOpen, onClose, onLogout }) => (
  <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
    <div className={styles.header}>
      <img src="/banner.svg" alt="Logo" className={styles.logo} />
      <button className={styles.closeBtn} onClick={onClose}>
        <FiX size={24} />
      </button>
    </div>

    <nav className={styles.nav}>
      {navItems.map(({ to, icon, label }) => (
        <NavLink
          key={to}
          to={to}
          className={styles.navItem}
          activeClassName={styles.active}
          onClick={onClose}
        >
          <span className={styles.icon}>{icon}</span>
          <span className={styles.label}>{label}</span>
        </NavLink>
      ))}
    </nav>

    {/* logout only on mobile */}
    <button className={styles.logoutMobile} onClick={onLogout}>
      <FiLogOut size={18} style={{ marginRight: 8 }} />
      Uitloggen
    </button>
  </aside>
);

export default Sidebar;
